package com.eleng.englishback.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import com.eleng.englishback.domain.Exercise;
import com.eleng.englishback.repository.ExerciseRepository;
import java.util.List;
@RestController
@RequestMapping("api/exercises")
@RequiredArgsConstructor
public class ExerciseController {
    private final ExerciseRepository exerciseRepository;
    @GetMapping
    public List<Exercise> getAllExercises(){
        return exerciseRepository.findAll();
    }
    @GetMapping("/lesson/{lessonId}")
    public List<Exercise> getExercisesByLessonId(@PathVariable Long lessonId){
        return exerciseRepository.findByLessonId(lessonId);
    }

    
    
}
