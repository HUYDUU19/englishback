package com.eleng.englishback.controller;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import com.eleng.englishback.domain.ExerciseQuestion;
import com.eleng.englishback.repository.ExerciseQuestionRepository;

@RestController
@RequestMapping("/api/exercise-questions")
@RequiredArgsConstructor
public class ExerciseQuestionController {

    private final ExerciseQuestionRepository exerciseQuestionRepository;

    @GetMapping("/exercise/{exerciseId}")
    public List<ExerciseQuestion> getQuestionsByExercise(@PathVariable Long exerciseId) {
        return exerciseQuestionRepository.findByExerciseId(exerciseId);
    }
}
