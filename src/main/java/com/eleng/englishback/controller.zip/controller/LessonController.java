package com.eleng.englishback.controller;

import org.springframework.web.bind.annotation.*;
import com.eleng.englishback.domain.Lesson;
import com.eleng.englishback.repository.LessonRepository;

import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("api/lessons")
@RequiredArgsConstructor
public class LessonController {
    private final LessonRepository lessonRepository;
    @GetMapping
    public List<Lesson>getAllLessons(){
        return lessonRepository.findAll();
    }
    @GetMapping("/level/{level}")
    public List<Lesson>getLessonsByLevel(@PathVariable String level){
        return lessonRepository.findByLevelIgnoreCase(level);
    }
    @GetMapping("/{id}")
    public Lesson getLessonById(@PathVariable Long id){
        return lessonRepository.findById(id).orElseThrow();
    }
   

}
